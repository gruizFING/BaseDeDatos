---------- bloque 2 ----------------

select * 
from alquileres 
where
	idpelicula = 25
	and idcliente = 249
	and fecha = '2010-10-15'
	and idpersonal = 10
;

select * 
from alquileres 
where
	idpelicula = 13
	and idcliente = 124
	and fecha = '2010-10-21'
	and idpersonal = 5
;

select *
from pagos
where 
	idpeliculaalquilo = 13
	and idclientealquilo = 124
	and idSucursalalquilo = 2
	and idpersonalalquilo = 5
	and fechaalquilo = '2010-10-21'
;

select * 
from alquileres 
where
	idpelicula = 1500
	and idcliente = 43
	and fecha = '2010-02-13'
	and idpersonal = 7
;

select *
from pagos
where 
	idpeliculaalquilo = 13
	and idclientealquilo = 124
	and idSucursalalquilo = 2
	and idpersonalalquilo = 5
	and fechaalquilo = '2010-10-23'
;