-------------- bloque 1 -----------------
select * 
from alquileres 
where
	idpelicula = 870
	and idcliente = 251
	and fecha = '2010-02-13'
	and idpersonal = 7
;

select * 
from alquileres 
where
	idpelicula = 405
	and idcliente = 192
	and fecha = '2010-02-13'
	and idpersonal = 7
;

select * 
from alquileres 
where
	idpelicula = 600
	and idcliente = 43
	and fecha = '2010-02-13'
	and idpersonal = 7
;

select *
from pagos
where 
	idpeliculaalquilo = 405
	and idclientealquilo = 192
	and idSucursalalquilo = 4
	and idpersonalalquilo = 7
	and fechaalquilo = '2010-02-13'
;