user="bdatosNN"
pass="********"

echo "realizando consultas..."
psql -h dbpgens -U $user bdatosdb --file=bloque2.sql --output=bloque2-antes.txt

echo "compilando..."
javac Tarea4Parte2.java

echo "ejecutando..."
java -classpath '.:postgresql-jdbc.jar' Tarea4Parte2 parte2.in dbpgens 5432 bdatosdb $user $pass

echo "realizando consultas..."
psql -h dbpgens -U $user bdatosdb --file=bloque1.sql --output=bloque1-despues.txt
psql -h dbpgens -U $user bdatosdb --file=bloque2.sql --output=bloque2-despues.txt

echo "comparando archivo de salida..."
diff $user-resultados.txt test2-resultados.txt

echo "comparando resultados de consultas bloque1.sql..."
diff bloque1-despues.txt bloque1-despues.out

echo "comparando resultados de consultas bloque2.sql..."
diff bloque2-antes.txt bloque2-despues.txt
